# Sala Virtual Prof. JC

Versão inicial baseada nas imagens fornecidas.

## Professor
Usuário: junioc
Senha: 047976

## Horário escolar
O professor pode alterar:
- horário de início de cada aula;
- horário de término de cada aula;
- disciplina de cada dia;
- cada turma separadamente.

Exemplo aceito: 08:00–10:00.

## Observação
Esta versão funciona localmente no navegador e armazena alterações no `localStorage`.
Para uso simultâneo real por professor e alunos em aparelhos diferentes, será necessário adicionar backend/banco de dados e publicar o sistema.
